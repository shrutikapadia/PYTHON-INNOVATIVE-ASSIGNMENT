import numpy as np
a=np.array([[3,2,2],[1,-1,5],[0,5,1]])
b=np.array([3,7,-1])
x=np.linalg.inv(a).dot(b)
print(x)