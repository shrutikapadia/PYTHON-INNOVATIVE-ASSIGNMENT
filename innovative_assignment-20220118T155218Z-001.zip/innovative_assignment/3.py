import matplotlib.pyplot as plt
import numpy as np
from scipy import interpolate
x = np.array([1, 2, 3, 4, 5])
y = np.array([1,9,50,300,1500])
x_new = np.linspace(1, 4, 300)
a_BSpline = interpolate.make_interp_spline(x, y)
y_new = a_BSpline(x_new)
plt.plot(x_new, y_new)
plt.show()