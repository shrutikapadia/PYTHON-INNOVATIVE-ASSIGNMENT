import csv
from matplotlib import pyplot as plt

file_1 = "data.csv"

with open(file_1, "r") as csvfile:
    csvr = csv.reader(csvfile)
    
    flag = 0
    day = list()
    open_ = list()
    high = list()
    low = list()
    close = list()
    
    for row in csvr:
        if(flag != 0):
            day.append(row[0])
            open_.append(float(row[1]))
            high.append(float(row[2]))
            low.append(float(row[3]))
            close.append(float(row[4]))
        else:
            flag += 1
            
plt.plot(day,open_,c="blue",label="open")
plt.plot(day,close,c="red",label="close")
plt.plot(day,high,c="green",label="high")
plt.plot(day,low,c="yellow",label="low")

plt.ylim(770,782)
plt.xlabel("day")
plt.ylabel("price")
plt.legend(loc="upper left")
plt.show()